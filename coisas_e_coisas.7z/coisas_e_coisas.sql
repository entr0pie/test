CREATE TABLE Customers (
	id INT NOT NULL AUTO_INCREMENT,
    CPF VARCHAR(11) NOT NULL,
    name VARCHAR(64) NOT NULL,
    surname VARCHAR(255) NOT NULL,
    PRIMARY KEY(id)
);

CREATE TABLE Workers (
	id INT NOT NULL AUTO_INCREMENT,
    CPF VARCHAR(11) NOT NULL,
    name VARCHAR(64) NOT NULL,
    surname VARCHAR(255) NOT NULL,
    date_birth DATE NOT NULL,
    phone_number VARCHAR(13) NOT NULL,
    address VARCHAR(255) NOT NULL,
    PRIMARY KEY (id)
);

CREATE TABLE Services (
	id INT NOT NULL AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    type VARCHAR(255) NOT NULL,
    price DOUBLE NOT NULL,
    PRIMARY KEY (id)
);

CREATE TABLE Requests (
	id INT NOT NULL AUTO_INCREMENT,
    contract_date DATE NOT NULL,
    customer_id INT NOT NULL,
    services INT NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (customer_id) REFERENCES Customers(id)
);


CREATE TABLE Workers_Services (
	id INT NOT NULL AUTO_INCREMENT,
    service INT NOT NULL,
    worker INT NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (service) REFERENCES Services(id),
    FOREIGN KEY (worker) REFERENCES Workers(id)
);


CREATE TABLE Requests_Services (
	id INT NOT NULL AUTO_INCREMENT,
    request INT NOT NULL,
    service INT NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (request) REFERENCES Requests (id),
    FOREIGN KEY (service) REFERENCES Services (id)
);

INSERT INTO Customers(CPF, name, surname) VALUES
("111", "Pedro", "de Lara");

 UPDATE SET CPF = '111', name = 'João', surname = 'de Lara' WHERE id = 1;

USE coisas_e_coisas;
SELECT * FROM Customers;

DELETE FROM Customers WHERE id = 10;